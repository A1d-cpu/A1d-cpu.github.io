        // 初始化技能进度条动画
        window.addEventListener('load', () => {
            document.querySelectorAll('.progress-value').forEach(bar => {
                bar.style.width = '0';
                setTimeout(() => {
                    bar.style.width = bar.parentElement.previousElementSibling.querySelector('span').textContent.replace('%', '') + '%';
                }, 300);
            });
        });

        // 导航栏高亮
        const menuLinks = document.querySelectorAll('.menu a');
        window.addEventListener('scroll', () => {
            const scrollPosition = window.scrollY + 80;
            menuLinks.forEach(link => {
                const targetId = link.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                if (targetElement && targetElement.offsetTop <= scrollPosition && targetElement.offsetTop + targetElement.offsetHeight > scrollPosition) {
                    menuLinks.forEach(l => l.classList.remove('active'));
                    link.classList.add('active');
                }
            });
        });

        // 平滑滚动
        menuLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            });
        });

        // 轮播图
        const carouselItems = document.querySelectorAll('.carousel-item');
        const carouselDots = document.querySelectorAll('.carousel-dot');
        const prevBtn = document.querySelector('.prev');
        const nextBtn = document.querySelector('.next');
        let currentIndex = 0;
        let carouselInterval;

        function showSlide(index) {
            carouselItems.forEach(item => item.classList.remove('active'));
            carouselDots.forEach(dot => dot.classList.remove('active'));
            carouselItems[index].classList.add('active');
            carouselDots[index].classList.add('active');
            currentIndex = index;
        }

        function nextSlide() {
            let index = (currentIndex + 1) % carouselItems.length;
            showSlide(index);
        }

        function prevSlide() {
            let index = (currentIndex - 1 + carouselItems.length) % carouselItems.length;
            showSlide(index);
        }

        carouselDots.forEach((dot, index) => {
            dot.addEventListener('click', () => showSlide(index));
        });

        prevBtn.addEventListener('click', prevSlide);
        nextBtn.addEventListener('click', nextSlide);

        // 轮播图自动播放
        carouselInterval = setInterval(nextSlide, 3000);
        document.querySelector('.carousel').addEventListener('mouseenter', () => clearInterval(carouselInterval));
        document.querySelector('.carousel').addEventListener('mouseleave', () => carouselInterval = setInterval(nextSlide, 3000));

        // 项目筛选
        const filterBtns = document.querySelectorAll('.filter-btn');
        const projectCards = document.querySelectorAll('.project-card');
        const projectGrid = document.getElementById('projectGrid');

        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const filter = btn.getAttribute('data-filter');
                
                projectCards.forEach(card => {
                    if (filter === 'all' || card.getAttribute('data-category') === filter) {
                        card.style.display = 'block';
                        // 添加淡入动画
                        card.style.opacity = '0';
                        setTimeout(() => card.style.opacity = '1', 100);
                    } else {
                        card.style.display = 'none';
                    }
                });
                // 重置分页
                document.querySelectorAll('.page-btn')[0].click();
            });
        });

        // 项目排序
        const sortSelect = document.getElementById('sortSelect');
        sortSelect.addEventListener('change', () => {
            const sortValue = sortSelect.value;
            const cardsArray = Array.from(projectCards).filter(card => card.style.display !== 'none');

            switch (sortValue) {
                case 'latest':
                    cardsArray.sort((a, b) => new Date(b.getAttribute('data-date')) - new Date(a.getAttribute('data-date')));
                    break;
                case 'oldest':
                    cardsArray.sort((a, b) => new Date(a.getAttribute('data-date')) - new Date(b.getAttribute('data-date')));
                    break;
                case 'name-asc':
                    cardsArray.sort((a, b) => a.getAttribute('data-name').localeCompare(b.getAttribute('data-name')));
                    break;
                case 'name-desc':
                    cardsArray.sort((a, b) => b.getAttribute('data-name').localeCompare(a.getAttribute('data-name')));
                    break;
            }

            projectGrid.innerHTML = '';
            cardsArray.forEach(card => {
                projectGrid.appendChild(card);
                // 添加淡入动画
                card.style.opacity = '0';
                setTimeout(() => card.style.opacity = '1', 100);
            });
            // 重置分页
            document.querySelectorAll('.page-btn')[0].click();
        });

        // 项目分页功能
        const pageBtns = document.querySelectorAll('.page-btn');
        const itemsPerPage = 6; // 每页显示6个项目
        
        function renderPage(pageNum) {
            const visibleCards = Array.from(projectCards).filter(card => card.style.display !== 'none');
            const totalPages = Math.ceil(visibleCards.length / itemsPerPage);
            
            // 高亮当前页按钮
            pageBtns.forEach((btn, index) => {
                btn.classList.remove('active');
                if (parseInt(btn.getAttribute('data-page')) === pageNum) {
                    btn.classList.add('active');
                }
            });

            // 显示对应页的项目
            visibleCards.forEach((card, index) => {
                const cardPage = Math.floor(index / itemsPerPage) + 1;
                if (cardPage === pageNum) {
                    card.style.display = 'block';
                    // 淡入动画
                    card.style.opacity = '0';
                    setTimeout(() => card.style.opacity = '1', 100);
                } else {
                    card.style.display = 'none';
                }
            });
        }

        pageBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const pageNum = parseInt(btn.getAttribute('data-page'));
                renderPage(pageNum);
            });
        });

        // 项目详情页图片切换
        const galleryImgs = document.querySelectorAll('.gallery-img');
        const thumbImgs = document.querySelectorAll('.thumb-img');

        thumbImgs.forEach((thumb, index) => {
            thumb.addEventListener('click', () => {
                galleryImgs.forEach(img => {
                    img.classList.remove('active');
                    img.style.opacity = '0';
                });
                thumbImgs.forEach(t => t.classList.remove('active'));
                
                galleryImgs[index].classList.add('active');
                setTimeout(() => galleryImgs[index].style.opacity = '1', 100);
                thumbImgs[index].classList.add('active');
            });
        });

        // 下载代码功能
        function downloadCode() {
            // 创建下载链接
            const a = document.createElement('a');
            a.href = 'download/个人求职网站代码.zip'; // 代码包路径，需自行替换
            a.download = '黄法敬-个人求职网站代码.zip';
            
            // 模拟下载提示
            alert('即将开始下载项目代码包，请稍候...');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }

        // 表单验证
        function submitForm() {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            let isValid = true;

            // 姓名验证
            if (!name) {
                showError('name', '请输入姓名');
                isValid = false;
            } else {
                hideError('name');
            }

            // 邮箱验证
            const emailReg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email) {
                showError('email', '请输入邮箱');
                isValid = false;
            } else if (!emailReg.test(email)) {
                showError('email', '请输入正确的邮箱格式');
                isValid = false;
            } else {
                hideError('email');
            }

            // 主题验证
            if (!subject) {
                showError('subject', '请输入联系主题');
                isValid = false;
            } else {
                hideError('subject');
            }

            // 消息内容验证
            if (!message) {
                showError('message', '请输入消息内容');
                isValid = false;
            } else {
                hideError('message');
            }

            if (isValid) {
                // 模拟表单提交
                const submitBtn = document.querySelector('.submit-btn');
                submitBtn.disabled = true;
                submitBtn.textContent = '提交中...';
                
                setTimeout(() => {
                    alert('消息提交成功！我会尽快与您联系~');
                    document.getElementById('contactForm').reset();
                    submitBtn.disabled = false;
                    submitBtn.textContent = '提交消息';
                }, 1000);
            }
        }

        function showError(id, message) {
            const input = document.getElementById(id);
            const errorMsg = input.nextElementSibling;
            input.classList.add('error');
            errorMsg.textContent = message;
            errorMsg.style.display = 'block';
            
            // 抖动动画
            input.style.animation = 'shake 0.5s';
            setTimeout(() => input.style.animation = '', 500);
        }

        function hideError(id) {
            const input = document.getElementById(id);
            const errorMsg = input.nextElementSibling;
            input.classList.remove('error');
            errorMsg.style.display = 'none';
        }

        // 添加表单输入实时验证
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('input', () => {
                if (input.classList.contains('error')) {
                    const id = input.id;
                    if (id === 'name' && input.value.trim()) hideError(id);
                    if (id === 'email' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim())) hideError(id);
                    if (id === 'subject' && input.value.trim()) hideError(id);
                    if (id === 'message' && input.value.trim()) hideError(id);
                }
            });
        });

        // 页面滚动动画
        const observerOptions = {
            threshold: 0.1
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // 为需要动画的元素添加初始样式
        document.querySelectorAll('.info-card, .project-card, .contact-form, .contact-info').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
            observer.observe(el);
        });

        // 添加抖动动画样式
        const style = document.createElement('style');
        style.textContent = `
            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                20%, 60% { transform: translateX(-5px); }
                40%, 80% { transform: translateX(5px); }
            }
        `;
        document.head.appendChild(style);